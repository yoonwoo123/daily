from django.shortcuts import render, HttpResponse
# Create your views here.

def info(request):
    return render(request, 'info.html')
    
def student(request, name):
    my_info = {'yoon': '26', 'park' : '22', '박길동': '28'}
    age = my_info[name]
    return render(request, 'student.html', {'name': name, 'age': age})