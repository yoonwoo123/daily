from django.apps import AppConfig


class YoonwooConfig(AppConfig):
    name = 'yoonwoo'
